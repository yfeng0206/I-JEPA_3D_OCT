Upload this zip to Overleaf and set main.tex as the root document.
Compiler: XeLaTeX or pdfLaTeX. Bibliography: BibTeX.
All numeric quantities resolve through auto/auto_numbers.tex,
which is generated from stored per-case predictions.
Do not edit auto/ by hand.
